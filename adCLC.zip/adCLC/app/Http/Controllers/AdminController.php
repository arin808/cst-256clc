<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Business\BusinessService;
use App\Models\UserModel;
use App\Http\Middleware\Suspended;

class AdminController extends Controller
{
    public function index()
    {
        // Instantiate Business layer to access data
        $bs = new BusinessService();
        
        //Obtain data
        $users = $bs->getAll();
        
        return view('admin')->with('users', $users);
    }
    
    public function editView(Request $request)
    {
        $id = request()->get('id');
        $bs = new BusinessService();
        
        $user = $bs->getUser($id);
        
        return View('editUser')->with('user', $user);
    }
    
    public function editUser(Request $request)
    {
        $id = request()->get('id');
        $name = request()->get('name');
        $email = request()->get('email');
        $password = request()->get('password');
        $role = request()->get('role');
        $user = new UserModel($id, $name, $email, $password, $role);
        
        $bs = new BusinessService();
        
        $bs->editUser($user);
  
        $all = $bs->getAll();
        return View('admin')->with('users', $all);
    }
    
    public function suspend(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new BusinessService();
        
        if($bs->suspend($id))
        {
            echo "success";
            return View('admin');
        }
        else 
        {
            echo "fail";
        }
        
    }
    
    public function delete(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new BusinessService();
        
        $bs->delete($id);
        return View('admin');
    }
}
