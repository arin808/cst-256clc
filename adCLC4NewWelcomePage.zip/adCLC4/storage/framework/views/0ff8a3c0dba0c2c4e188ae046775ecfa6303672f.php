
<?php $__env->startSection('content'); ?>

<html>
	<table style="width: 1300px; height:100px" cellpadding="15" border="1" align="center" id="admin">
		<thead>
			<tr align="center">
				<th>Group Name</th>
				<th>Common Interest</th>
				<th>Group Type</th>
				<th>Group Members</th>
				<th>Group Description</th>
				<th>View</th>
				<th>Join/Leave</th>
			</tr>
		</thead>
		<tbody align="center"> 
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<tr>
                    	<td><?php echo e($group->getGroupName()); ?></td>
                    	<td><?php echo e($group->getInterest()); ?></td>
                    	<td><?php echo e($group->getType()); ?></td>
                    	<td><?php echo e($group->getMemberCount()); ?></td>
                    	<td><?php echo e($group->getDescription()); ?></td>
            			<td>
            				<form action='viewGroup' method="post">
                            	<?php echo e(csrf_field()); ?>

                    			<input type='hidden' name='groupID' value='<?php echo e($group->getGroupID()); ?>'>
                    			<input type='submit' value='View'>
                			</form>
                		</td>
                		<?php if($group->getExists() == false): ?>
                		<td>
                            <form action='joinGroup' method="post">
                            	<?php echo e(csrf_field()); ?>

                    			<input type='hidden' name='groupID' value='<?php echo e($group->getGroupID()); ?>'>
                    			<input type='submit' value='Join'>
                			</form>
            			</td>
						<?php endif; ?>
						<?php if($group->getExists() == true): ?>
                		<td>
                            <form action='leaveGroup' method="post">
                            	<?php echo e(csrf_field()); ?>

                    			<input type='hidden' name='groupID' value='<?php echo e($group->getGroupID()); ?>'>
                    			<input type='submit' value='Leave'>
                			</form>
            			</td>
						<?php endif; ?>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/groupPages/groupUserView.blade.php ENDPATH**/ ?>