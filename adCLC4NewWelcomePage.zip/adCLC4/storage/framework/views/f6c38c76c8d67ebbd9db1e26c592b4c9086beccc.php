 <?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header"><?php echo e(__('More User Info')); ?></div>

				<div class="card-body">
					<form method="POST" action="addNewInfo">
						<?php echo e(csrf_field()); ?>


						<div class="form-group row">
							<label for="name" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Age')); ?></label>

							<div class="col-md-6">
								<input id="age" type="text"
									class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="age" value="<?php echo e(old('age')); ?>" required autocomplete="age"
									autofocus> <?php if ($errors->has('age')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('age'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label for="gender" class="col-md-4 col-form-label text-md-right">Gender</label>

							<div class="col-md-6">
								<select name="gender" class="form-control">
									<option selected="selected">Choose Gender</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								</select>
							</div>
						</div>
						
						<div class="form-group row">
							<label for="phonenumber" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Phone Number')); ?></label>
							<div class="col-md-6">
								<input id="phonenumber" type="text"
									class="form-control <?php if ($errors->has('phonenumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phonenumber'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="phonenumber" value="<?php echo e(old('phonenumber')); ?>" required autocomplete="phonenumber"
									autofocus> <?php if ($errors->has('phonenumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phonenumber'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label for="address" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Address')); ?></label>
							<div class="col-md-6">
								<input id="address" type="text"
									class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="address" value="<?php echo e(old('address')); ?>" required autocomplete="address"
									autofocus> <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row mb-0">
							<div class="col-md-6 offset-md-4">
								<button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/moreinfo.blade.php ENDPATH**/ ?>