<html>
	<h2 style="margin-left: 30px">CLC Laravel Project</h2>
</html><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/layouts/header.blade.php ENDPATH**/ ?>