 <?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header"><?php echo e(__('Create Your User Portfolio To Show Potential Employers!')); ?></div>

				<div class="card-body">
					<form method="POST" action="addUserPortfolio">
						<?php echo e(csrf_field()); ?>


						<div class="form-group row">
							<label for="name" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Job History')); ?></label>

							<div class="col-md-6">
								<input id="jobHistory" type="text"
									class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="jobHistory" value="<?php echo e(old('jobHistory')); ?>" required autocomplete="joHhistory"
									autofocus> <?php if ($errors->has('jobHistory')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobHistory'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label for="name" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Job Skills')); ?></label>

							<div class="col-md-6">
								<input id="jobSkills" type="text"
									class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="jobSkills" value="<?php echo e(old('jobSkills')); ?>" required autocomplete="jobSkills"
									autofocus> <?php if ($errors->has('jobSkills')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobSkills'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						
						<div class="form-group row">
							<label for="education" class="col-md-4 col-form-label text-md-right">
							<?php echo e(__('Education')); ?></label>
							<div class="col-md-6">
								<input id="education" type="text"
									class="form-control <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									name="education" value="<?php echo e(old('education')); ?>" required autocomplete="education"
									autofocus> <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?> <span class="invalid-feedback"
									role="alert"> <strong><?php echo e($message); ?></strong>
								</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						
						<div class="form-group row mb-0">
							<div class="col-md-6 offset-md-4">
								<button type="submit" class="btn btn-primary"> <?php echo e(__('Save')); ?></button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/userPortfolio.blade.php ENDPATH**/ ?>