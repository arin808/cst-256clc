

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Affinity Group')); ?></div>
               <div class="card-body">
                    <form method="POST" action="editGroup">
                        <?php echo e(csrf_field()); ?>

						<input type="hidden" name="groupID" value="<?php echo e($group->getGroupID()); ?>">
                       	<div class="form-group row">
                            <label for="groupName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Group Name')); ?></label>

                            <div class="col-md-6">
                                <input id="groupName" value="<?php echo e($group->getGroupName()); ?>" type="text" class="form-control <?php if ($errors->has('groupName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupName'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="groupName" required autocomplete="groupName" autofocus>

                                <?php if ($errors->has('groupName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupName'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="interest" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Common Interest')); ?></label>

                            <div class="col-md-6">
                                <input id="interest" value="<?php echo e($group->getInterest()); ?>" type="text" class="form-control <?php if ($errors->has('interest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('interest'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="interest"  required autocomplete="interest">

                                <?php if ($errors->has('interest')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('interest'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                        	<label for="type" class="col-md-4 col-form-label text-md-right">Group Type</label>
                      		<div class="col-md-6">
                              	<select name="type" class="form-control" >
                            		<option selected="selected">Choose Group Type</option> 
                            		<option value="Business">Business</option>
									<option value="Personal">Personal</option>
								</select>
                         	</div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <input id="description" value="<?php echo e($group->getDescription()); ?>" type="text" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description"  required autocomplete="description">

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Edit Group')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/groupPages/editGroup.blade.php ENDPATH**/ ?>