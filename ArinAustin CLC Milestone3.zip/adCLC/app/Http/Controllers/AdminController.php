<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\Business\UserBS;
use App\Models\UserModel;
use App\Models\MoreinfoModel;
use App\Services\Business\JobListBS;
use App\Models\JobListingModel;
use App\Models\UserPortfolioModel;

class AdminController extends Controller
{
    // Direct route to admin page
    public function index()
    {
        // Instantiate Business layer to access data
        $bs = new UserBS();
        
        //Obtain data
        $users = $bs->getAll();

        return view('admin')->with('users', $users);
    }
    
    // Controller that takes id to autofill form
    public function editView(Request $request)
    {
        $id = request()->get('id');
        $bs = new UserBS();
        
        $user = $bs->getUser($id);
        
        return View('editUser')->with('user', $user);
    }
    
    // Admin edit user function
    public function editUser(Request $request)
    {
        $id = request()->get('id');
        $name = request()->get('name');
        $email = request()->get('email');
        $password = request()->get('password');
        $role = request()->get('role');
        $user = new UserModel($id, $name, $email, $password, $role);
        
        $bs = new UserBS();
        
        $bs->editUser($user);
  
        $all = $bs->getAll();
        if(Auth::user()->role == 'admin')
        {
            return View('admin')->with('users', $all);   
        }
        else 
        {
            return View('home');
        }
    }
    
    // Admin suspend user
    public function suspend(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new UserBS();
        
        
        if($bs->suspend($id))
        {
            echo "success";
        }
        else 
        {
            echo "fail";
        }
        $users = $bs->getAll();
        
        return View('admin')->with('users', $users);
        
    }
    
    // Admin user delete function
    public function delete(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new UserBS();
        
        $bs->delete($id);
        
        $users = $bs->getAll();
        
        return View('admin')->with('users', $users);
    }
    
    // Method to add additional user info
    public function addNewInfo(Request $request)
    {
        $moreInfoData = new MoreInfoModel(request()->get('age'), request()->get('gender'),request()->get('phonenumber'),request()->get('address'));
        
        $bs = new UserBS();
        
        $id = Auth::user()->id;
        
        $isValid = $bs->addNewInfo($moreInfoData, $id);
        
        if($isValid)
        {
            echo("customer data added!");
            return view('home');
        }
        else
        {
            echo("customer data not added. you got it next time!");
            return view('moreinfo');
        }
        
    }
    
    //===================Job Listing functions=================
    // Method to direct to job admin page
    public function jobAdmin()
    {
        $bs = new JobListBS();
        
        $jobs = $bs->getAllJobs();
        
        return view('jobAdmin')->with('jobs', $jobs);
    }
    // Method to add job listing
    public function addJob(Request $request)
    {
        $id = 0;
        $company = request()->get('company');
        $position = request()->get('position');
        $location = request()->get('location');
        $experience = request()->get('experience');
        $skills = request()->get('skills');
        
        $job = new JobListingModel($id, $company, $position, $location, $experience, $skills);
        
        $bs = new JobListBS();
        
        $bs->addJob($job);
        
        $jobs = $bs->getAllJobs();
        
        return view('jobAdmin')->with('jobs', $jobs);
    }
    
    // Controller that takes id to autofill form
    public function editJob(Request $request)
    {
        $id = request()->get('id');
        $bs = new JobListBS();
        
        $job = $bs->getJob($id);
        
        return View('editJobListing')->with('job', $job);
    }
    
    public function editJobData(Request $request)
    {
        $jobID = request()->get('jobID');
        $company = request()->get('company');
        $position = request()->get('position');
        $location = request()->get('location');
        $experience = request()->get('experience');
        $skills = request()->get('skills');
        
        $temp = new JobListingModel($jobID, $company, $position, $location, $experience, $skills);
        
        $bs = new JobListBS();
        $bs->editJob($temp);
        
        $jobs = $bs->getAllJobs();
        
        return View('jobAdmin')->with('jobs', $jobs);
    }
    
    public function deleteJob(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new JobListBS();
        $bs->deleteJob($id);
        $jobs = $bs->getAllJobs();
        
        return View('jobAdmin')->with('jobs', $jobs);
    }
    
    public function addUserPortfolio(Request $request)
    {
        $id = Auth::user()->id;
        
        $jobSkills = request()->get('jobSkills');
        $jobHistory = request()->get('jobHistory');
        $education = request()->get('education');
        $temp = new UserPortfolioModel($jobSkills, $jobHistory, $education);
        
        $bs = new UserBS();
        $bs->addUserPortfolio($temp, $id);
        
        $portfolio = $bs->getUserPortfolio($id);
        return View('/displayUserPortfolio')->with('portfolio', $portfolio);
       
    }
}
