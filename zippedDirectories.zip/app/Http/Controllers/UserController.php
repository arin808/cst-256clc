<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use App\Services\Business\UserBS;
use App\Models\UserModel;
use App\Models\MoreinfoModel;
use App\Services\Business\JobListBS;
use App\Services\Data\Utility\ILoggerService;
use App\Models\JobListingModel;
use App\Models\UserPortfolioModel;
use Carbon\Exceptions\Exception;
use App\Services\Business\GroupBS;

class UserController extends Controller
{
	public function __construct(ILoggerService $logger)
	{
		$logger->info("Entering the user controller");
		try
		{
			$this->middleware('auth')->except('logout');
		}
		catch (Exception $e)
		{
			$logger->error("Error:", $e);
		}
	}
    // Direct route to admin page
    public function index()
    {

    }
    
    // Method to add additional user info
    public function addNewInfo(Request $request)
    {
        $moreInfoData = new MoreInfoModel(request()->get('age'), request()->get('gender'),request()->get('phonenumber'),request()->get('address'));
        
        $bs = new UserBS();
        
        $id = Auth::user()->id;
        
        $isValid = $bs->addNewInfo($moreInfoData, $id);
        
        if($isValid)
        {
            return view('home');
        }
        else
        {
            return view('moreinfo');
        }
        
    }
       
    public function addUserPortfolio(Request $request)
    {
        $id = Auth::user()->id;
        
        $jobSkills = request()->get('jobSkills');
        $jobHistory = request()->get('jobHistory');
        $education = request()->get('education');
        $temp = new UserPortfolioModel($jobSkills, $jobHistory, $education);
        
        $bs = new UserBS();
        $bs->addUserPortfolio($temp, $id);
        
        $portfolio = $bs->getUserPortfolio($id);
        return View('/displayUserPortfolio')->with('portfolio', $portfolio);
       
    }
    
    //User see all job listings
    public function allJobs()
    {
    	$bs = new JobListBS();
    	
    	$jobs = $bs->getAllJobs();
    	
    	return view('/userPages/viewAllJobs')->with('jobs', $jobs);
    }
    // User search job
    public function searchJob(Request $request)
    {
    	$bs = new JobListBS();
    	
    	$searchTerm = request()->get('searchTerm');
    	
    	$jobs = $bs->searchJob($searchTerm);
    	
    	return View('/userPages/searchJobResults')->with('jobs', $jobs);
    }
    public function viewOneJob(Request $request)
    {
    	$id = request()->get('id');
    	$userID = Auth::user()->id;
    	$bs = new JobListBS();
    	
    	$job = $bs->getJob($id);
    	
    	$exists = $bs->isApplied($id, $userID);
    	
    	return View('/userPages/viewOneJob')->with('job', $job)->with('exists', $exists);
    }
    public function apply(Request $request)
    {
    	$jobID = request()->get('id');
    	
    	$userID = Auth::user()->id;
    	$exists = false;
    	$bs = new JobListBS();
    	
    	$bs->apply($jobID, $userID);
    	$job = $bs->getJob($jobID);
	    $exists = $bs->isApplied($jobID, $userID);
	    	    
	    return View('/userPages/viewOneJob')->with('job', $job)->with('exists', $exists);
    }
    // view details
    public function details(Request $request)
    {
    	$id = Auth::user()->id;
    	$ubs = new UserBS();
    	$user = $ubs->getUser($id);
    	
    	$demos = $ubs->getInfo($id);
    	// get portfolio , demos and groups
    	$portfolio = $ubs->getUserPortfolio($id);
    	$groups = $ubs->getGroups($id);
    	//$demographics = $ubs->getUserInfo($id);
    	return View('/userPages/edituser')->with('user', $user)
    	->with('portfolio', $portfolio)
    	->with('groups', $groups)
    	->with('demos', $demos);
    	
    }
    public function doEdit(Request $request){
    	
    	$id = Auth::user()->id;
    	$input = Input::all();
    	$ubs = new UserBS();
    	$gbs = new GroupBS();
    	$demos = $ubs->getInfo($id);
    	$gid = request()->get('gid');
    	$portfolio = $ubs->getUserPortfolio($id);
    	$groups = $ubs->getGroups($id);
    	$demos = $ubs->getInfo($id);
    	$user = $ubs->getUser($id);
    	//---------  which button was clicked ------------
    	$action = Input::get('action', 'none');
    	//---------      Assign form data     ------------
    	// ---------- scan & parse input ID keys ------------
    	// ---------- if delete group button clicked return view to delete group------
    	if (is_numeric($action)) {
    		
    		//-----  Delete history in MVC ------
    		if ($gbs->leaveGroup((int)$action, $id)){
    			$groups = $ubs->getGroups($id);
    			return View('/userPages/edituser')->with('user', $user)
    			->with('portfolio', $portfolio)
    			->with('groups', $groups)
    			->with('demos', $demos);
    			
    			
    		}
    		else {
    			return View('/userPages/edituser')->with('user', $user)
    			->with('portfolio', $portfolio)
    			->with('groups', $groups)
    			->with('demos', $demos);
    		}
    	}
    	//         elseif ($action == 'dS'){
    	//             //-----  Delete skill in MVC ------
    	//             if ($service->deleteSkill($skillid))
    		//                 return view('yourportfolio');
    	
    	//                 echo $skillid; return view('yourportfolio');
    	//         }
    	//         elseif ($action == 'dE'){
    	//             //-----  Delete education in MVC ------
    	//             if ($service->deleteEducation($educationid))
    		//                 return view('yourportfolio');
    	
    	//                 echo $educationid; return view('yourportfolio');
    	//         }
    	//      <!--------- --- --------- else update user & portfolio ------------ --- --------------->
    	else if ($action == 'post') {
    		//                                -- instantiate all vars --
    		
    		// //             //                            -- create array of all input keys --
    		//             $keys = array_keys($input);
    		//             $index = 1;
    		$credentials = new UserModel(request()->get('user1'), request()->get('user2'), request()->get('user3'), request()->get('user4') , request()->get('user5'));
    		$info = new MoreInfoModel(request()->get('demo1'), request()->get('demo2'), request()->get('demo3'), request()->get('demo4'));
    		//             //      <!--------- --- --------- iterate input and push values into model ------------ --- --------------->
    		
    		$useredited = $ubs->editall($credentials, $info);
    		
    		$demos = $ubs->getInfo($id);
    		$user = $ubs->getUser($id);
    		if ($useredited) {
    			echo "success";
    		}
    		else {
    			echo "--";
    			echo $useredited;
    		}
    		return View('/edituser')->with('user', $user)
    		->with('portfolio', $portfolio)
    		->with('groups', $groups)
    		->with('demos', $demos);
    		
    	}	
	}
}

