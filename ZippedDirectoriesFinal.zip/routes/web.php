<?php

use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//landing route
Route::get('/', function () {
    return view('welcome');
});

//built-in routes
Auth::routes();

//redirect when an unauthorized user tries to access admin pages
Route::get('/unauthorized', function(){
	return view('unauthorized');})->name('unauthorized');
	
//logout route
Route::get('/logout', 'LoginController@logout')->name('logout');

//home route
Route::get('/home', 'HomeController@index')->name('home');

//reroute for security
Route::get('/SecurityReroute', function(){
    return view('SecurityReroute');
});
    
//suspended view
Route::get('/suspendedUser', function(){
    return view('suspendedUser');
});

///////////////////////////NOT USED//////////////////////////////
//middleware view NOT USED
Route::get('/customer', function(){
    echo "Hello customer";
})->middleware('customer');

//middleware view NOT USED
Route::get('/suspended', function(){
    echo "Hello suspended user";
})->middleware('suspended');

//NOT USED prior user edit info 
Route::get('blank', function(){
    return View('/userPages/blankEditUser');
});
/////////////////////////////////////////////////////////////////

//---Resourceful routes for APIs
Route::resource('/usersrest', 'RestController');
Route::resource('/jobsrest', 'JobsRestController');
Route::resource('/groupsrest', 'GroupsRestController');

//===================================================Admin Routes===============================================

//Default admin user page
Route::get('/admin', 'AdminController@index');

//admin edit user view
Route::post('/editView', 'AdminController@editView');

//edit function from edit user page
Route::post('/editUser', 'AdminController@editUser');

//suspend user
Route::post('/suspend', 'AdminController@suspend');

//deletes user
Route::post('/delete', 'AdminController@delete');

//view user
Route::post('viewUser', 'AdminController@details');

//admin job view
Route::get('/jobAdmin', 'AdminController@jobAdmin');

//add job from job admin
Route::get('/addJob', function(){
	if(Auth::user()->role=='admin')
	{
		return view('/adminPages/addJobListing');
	}
	else
	{
		return view('securityReroute');
	}});

//add job data route
Route::post('/addJobListing', 'AdminController@addJob');

//edit job view
Route::post('/editJobView', 'AdminController@editJob');

//edit job data
Route::post('/editJobData', 'AdminController@editJobData');

//delete job listing
Route::post('/deleteJob', 'AdminController@deleteJob');

//admin view for groups
Route::get('/adminGroup', 'AdminController@adminGroup');

//admin add groups view
Route::get('/addGroupView', function(){
	return view('/adminPages/addGroup');
});
	
//admin add group post data
Route::post('/addGroup', 'AdminController@addGroup');

//admin edit group view
Route::post('/editGroupView','AdminController@editGroupView');

//admin edit group data submit
Route::post('/editGroup', 'AdminController@editGroup');

//admin delete group
Route::post('/deleteGroup', 'AdminController@deleteGroup');

//forcibly remove member from group
Route::post('/removeMember', 'AdminController@removeMember');

//===============================================NON-ADMIN USER ROUTES===========================================

//view other user's profile
Route::post('theirProfile', 'UserController@theirProfile');

//view to add demographic info
Route::get('/moreinfo', function()
{
    return view('/userPages/moreinfo');
});

//submit demographic data
Route::post('/addNewInfo', 'UserController@addNewInfo');

//route to see all jobs
Route::get('/allJobs', 'UserController@allJobs');

//View profile route that shows all data and allows edits
Route::get('/viewProfile', 'UserController@details');

//route to edit data from view profile page
Route::post('/doEdit', 'UserController@doEdit');

//route for portfolio view
Route::get('/userPortfolio', function()
{
	return view('/userPages/userPortfolio');
});

//search user submit query view
Route::get('/searchUser', function()
{
	return view('/userPages/searchForUser');
});

//submit user search query
Route::post('/searchUserFunc', 'UserController@searchUser');

//submit portfolio data
Route::post('/addUserPortfolio', 'UserController@addUserPortfolio');

//=================================================Job Listing Routes============================================

//search job view
Route::get('/searchJob', function()
{
	return view('/userPages/searchForJob');
});

//search for job view
Route::post('/searchJobFunc', 'UserController@searchJob');

//view one job 
Route::post('/viewOneJob', 'UserController@viewOneJob');

//apply for job
Route::post('/applyJob', 'UserController@apply');


//=====================================================Group Routes=============================================

//view group members of a group
Route::post('/viewGroup', 'GroupController@viewGroupMembers');

//view all groups view
Route::get('/groups', 'GroupController@userGroupView');

//join group
Route::post('/joinGroup', 'GroupController@joinGroup');

//leave group
Route::post('/leaveGroup', 'GroupController@leaveGroup');

