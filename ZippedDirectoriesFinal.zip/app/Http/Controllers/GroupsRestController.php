<?php

namespace App\Http\Controllers;

use App\Models\DTO;
use App\Services\Business\UserBS;
use App\Services\Business\GroupBS;
use App\Services\Business\JobListBS;
use App\Services\Data\Utility\ILoggerService;
use Carbon\Exceptions\Exception;
class GroupsRestController extends Controller
{
	//Logger constructor
	public function __construct(ILoggerService $logger)
	{
		$logger->info("Entering the group rest controller");
		try
		{
			$this->middleware('auth')->except('logout');
		}
		catch (Exception $e)
		{
			$logger->error("Error:", $e);
		}
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	//Base group rest api 
	public function index()
	{
		$security = new GroupBS();
		$groups = $security->getAll();
		if ($groups == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $groups);
		$dto = json_encode($translate);
		return $dto;
	}
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	//group rest api for specific group
	public function show($id)
	{
		$security = new GroupBS();
		$group = $security->getGroup($id);
		if ($group == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $group);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	
}
