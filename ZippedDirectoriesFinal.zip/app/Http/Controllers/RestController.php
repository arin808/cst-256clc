<?php

namespace App\Http\Controllers;

use App\Models\DTO;
use App\Services\Business\UserBS;
use App\Services\Business\GroupBS;
use App\Services\Business\JobListBS;
use App\Services\Data\Utility\ILoggerService;
use Carbon\Exceptions\Exception;
class RestController extends Controller
{
	//Logging constructor
	public function __construct(ILoggerService $logger)
	{
		$logger->info("Entering the user rest controller");
		try
		{
			$this->middleware('auth')->except('logout');
		}
		catch (Exception $e)
		{
			$logger->error("Error:", $e);
		}
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	//User rest api for all
	public function index()
	{
		$security = new UserBS();
		$users = $security->getAll();
		if ($users == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $users);
		$dto = json_encode($translate);
		return $dto;
		
	}
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	//User api for specific user
	public function show($id)
	{
		$security = new UserBS();
		$user = $security->getUser($id);
		if ($user == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $user);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	public function groups(){
		$security = new GroupBS();
		$groups = $security->getAll();
		if ($groups == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $groups);
		$dto = json_encode($translate);
		return $dto;
	}
	public function oneGroup($id)
	{
		$security = new GroupBS();
		$group = $security->getGroup($id);
		if ($group == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $group);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	public function ports($id)
	{
		$security = new JobListBS();
		$ports = $security->getAllJobs();
		if ($ports == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $ports);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	public function port($id)
	{
		$security = new JobListBS();
		$port = $security->getJob($id);
		if ($port == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $port);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	
}
