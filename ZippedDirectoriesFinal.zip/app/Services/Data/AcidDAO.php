<?php
namespace App\Services\Data;

use App\Models\MoreInfoModel;
use App\Models\UserModel;
use App\Models\GroupModel;
use App\Models\UserPortfolioModel;
use Carbon\Exceptions\Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Arr;
use Whoops\Exception\ErrorException;

class AcidDAO

{
	// Define conn string
	private $conn;
	
	
	public function __construct($conn)
	{
		// Create a connection to db
		$this->conn = $conn;
		// Make sure to test conn for errors
	}
	
	/**
	 * Method to verify user credentials
	 * @param UserModel $user
	 */
	//update user's username from view profile page
	public function updatename($username, $id)
	{
	    try
	    {
	        $this->dbquery = "UPDATE usernames SET Username='{$username}'
                                WHERE userID='{$id}'";
	        
	        
	        // If the selected query returns a result set
	        $result = mysqli_query($this->conn, $this->dbquery);
	        
	        if($result > 0)
	        {
	            //mysqli_free_result($result);
	            // mysqli_close($this->conn);
	            return true;
	        }
	        else
	        {
	            //mysqli_free_result($result);
	            // mysqli_close($this->conn);
	            return false;
	        }
	    }
	    catch (Exception $e)
	    {
	        echo $e->getMessage();
	    }
	}
	//insert a user's username from view profile page
	public function insertname($username, $id)
	{
	    try
	    {
	        
	        $this->dbquery = "INSERT INTO usernames(Username, userID)
                               VALUES('$username', '$id')";
	        
	        
	        // If the selected query returns a result set
	        $result = mysqli_query($this->conn, $this->dbquery);
	        
	        if($result > 0)
	        {
	            //mysqli_free_result($result);
	            // mysqli_close($this->conn);
	            return true;
	        }
	        else
	        {
	            //mysqli_free_result($result);
	            // mysqli_close($this->conn);
	            return false;
	        }
	    }
	    catch (Exception $e)
	    {
	        echo $e->getMessage();
	    }
	}
	//update user data from view profile page
	public function updateUser(UserModel $credentials)
	{
		try
		{
			$this->dbquery = "UPDATE users SET name='{$credentials->name}',
                                email='{$credentials->email}'
                                WHERE id='{$credentials->id}'";
			
			
			// If the selected query returns a result set
			$result = mysqli_query($this->conn, $this->dbquery);
			
			if($result > 0)
			{
				//mysqli_free_result($result);
				//   mysqli_close($this->conn);
				return true;
			}
			else
			{
				//mysqli_free_result($result);
				//     mysqli_close($this->conn);
				return false;
			}
		}
		catch (ErrorException $e)
		{
			
		}
	}
	// update demographics info from view profile page
	public function updateInfo(MoreInfoModel $info)
	{
		try
		{
			$id = Auth::user()->id;
			$this->dbquery = "UPDATE moreinfo SET age='{$info->age}',
                                gender='{$info->gender}',
                                phonenumber='{$info->phonenumber}',
                                address='{$info->address}'
                                WHERE userID='$id'";
			
			
			// If the selected query returns a result set
			$result = mysqli_query($this->conn, $this->dbquery);
			
			if($result > 0)
			{
				//mysqli_free_result($result);
				//     mysqli_close($this->conn);
				return true;
			}
			else
			{
				//mysqli_free_result($result);
				//      mysqli_close($this->conn);
				return false;
			}
		}
		catch (Exception $e)
		{
			echo $e->getMessage();
		}
	}
}