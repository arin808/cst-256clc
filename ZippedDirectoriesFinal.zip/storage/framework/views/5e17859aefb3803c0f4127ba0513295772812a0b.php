<?php $__env->startSection('content'); ?>
<?php
use App\Services\Business\UserBS;
$bs = new UserBS();
?>
<html>
	<table style="width: 1300px; height:100px" cellpadding="15" border="1" align="center" id="admin">
		<thead>
			<tr align="center">
				<th>Profile</th>
				<th>Name </th>
				<th>Username</th>
				<th>Email</th>
				<th>Password</th>
				<th>Role</th>
				<th>Edit</th>
				<th>Suspend</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody align="center"> 
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<tr>
            			<td>
            			<form action="theirProfile" method="post">
                            	<?php echo e(csrf_field()); ?>

                            	<input type="hidden" name='id' value='<?php echo e($user->id); ?>'>
                    			<input type="submit" value='View'>
                			</form>
                			</td>
                			<?php $username = $bs->getUserName($user->id); if ($username == null) $username = "N/A"; ?>
                    	<td><?php echo e($user->name); ?></td>
                    	<td><?php echo e($username); ?></td>
                    	<td><?php echo e($user->email); ?></td>
                    	<td><?php echo e($user->password); ?></td>
                    	<td><?php echo e($user->role); ?></td>
                    	
                		<td>
                        	<form action="editView" method="post">
                            	<?php echo e(csrf_field()); ?>

                            	<input type="hidden" name='id' value='<?php echo e($user->id); ?>'>
                    			<input type="submit" value='Edit'>
                			</form>
                		</td>
            			
            			<td>
                            <form action='suspend' method="post">
                            	<?php echo e(csrf_field()); ?>

                    			<input type='hidden' name='id' value='<?php echo e($user->id); ?>'>
                    			<input type='submit' value='Suspend'>
                			</form>
            			</td>
            			
            			<td>
                			<form action="delete" method="post">
                			    <?php echo e(csrf_field()); ?>

                    			<input type='hidden' name='id' value='<?php echo e($user->id); ?>'>
                    			<input type='submit' value='Delete'>
            		    	</form>
                		</td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views//adminPages/admin.blade.php ENDPATH**/ ?>