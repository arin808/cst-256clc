<?php $__env->startSection('content'); ?>

<html>
	<table style="width: 1300px; height:100px" cellpadding="15" border="1" align="center" id="admin">
		<thead>
			<tr align="center">
				<th>Job ID</th>
				<th>Position Title</th>
				<th>Job Description</th>
				<th>View</th>
			</tr>
		</thead>
		<tbody align="center"> 
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<tr>
                	<td><?php echo e($job->getJobID()); ?></td>
                	<td><?php echo e($job->getPosition()); ?></td>
                	<td><?php echo e($job->getDescription()); ?></td>
                	<td>
                    	<form action="applyJob" method="post">
                           	<?php echo e(csrf_field()); ?>

  
                           	<input type="hidden" name='id' value='<?php echo e($job->getJobID()); ?>'>
                           	<?php if($job->getExists() == false){ ?>
                    		<input type="submit" value='Apply'>
                			<?php } else if($job->getExists() == true) { ?>
                			<input type="submit" disabled value='Applied'>
                			<?php } ?>
                		</form>
                	</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views//userPages/viewAllJobs.blade.php ENDPATH**/ ?>