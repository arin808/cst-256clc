<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Log;
use Closure;
use Illuminate\Support\Facades\Cache;

class MyTestMiddleware
{
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next)
	{
		Log::info("Entering Middleware");
		if ($request->username != null){
			Log::info("Not null, value :: " . $request->username);
			$value = Cache::store("file")->get("mydata");
			if ($value == null) {
				Log::info("1st cache value :: " . $request->username);
				Cache::store("file")->put("mydata", $request->username, 1);
			}
		}
		else {
			$value = Cache::store("file")->get("mydata");
			if ($value != null){
				Log::info("Retrieving username from cache ::" . $value);
			}
			else {
				Log::info("Cache failure (data is older than 1 minute)");
			}
		}
		return $next($request);
	}
}
