<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Providers\LoggingServiceProvider;
use App\Services\Data\Utility\ILoggerService;
use Carbon\Exceptions\Exception;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    protected  $logger;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(ILoggerService $logger)
    {
	    $logger->info("Entering the logging service");
    	try 
    	{
	        $this->middleware('guest')->except('logout');
    	} 
    	catch (Exception $e) 
    	{
    		$logger->error("Error:", $e);
    	}
    }
}
