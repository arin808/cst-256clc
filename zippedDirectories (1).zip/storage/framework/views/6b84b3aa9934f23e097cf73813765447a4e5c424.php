<html >
	<h5 align="center">Arin Aihara Austin Driver, and Chris King CLC Milestone Project</h5>
</html><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views/layouts/footer.blade.php ENDPATH**/ ?>