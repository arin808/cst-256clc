<html>
	<h2 style="margin-left: 30px">CLC Laravel Project</h2>
</html><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views/layouts/header.blade.php ENDPATH**/ ?>