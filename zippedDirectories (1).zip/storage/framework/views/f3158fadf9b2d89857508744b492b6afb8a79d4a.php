<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</html>
<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_ERROR);
function inc($matches) {
    return ++$matches[1];
}
$i = 0;
$uI = "user0";
$uL = "Property 0";
$pI = "exp0";
$pL = "Experience 0";
$gI = "group0";
$gL = "Group 0";
$dI = "demo0";
$dL = "Demographics 0";
$chain = "null";
$gIdentity = "gId0";
$x = 0;
?>
<!-- loop through history, assign new form group col -->
<!-- increment history, assign placeholder as history[x]->getHistory -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1> Admin Interface </h1>
<style>
.flex {
display: flex;
   flex-direction: row;
}
.responsive {
  max-width: 100%;
  height: auto;
}
</style>
<div class= "responsive">
<?php echo csrf_field(); ?>
<form method="POST" action='sendFR'>



<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<!--      ------------------ USER ----------------------------- -->

<div class="card" style="margin-top:10px">
<div class="card-header"><?php echo e(__('User')); ?></div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
<?php if($user == null): ?> 
<div class="form-group row">

<label for="userid" class="col-md-4 col-form-label text-md-right">ID</label>

<div class="col-md-6">
<input id="userid" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="userid" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus readonly placeholder="No Data Filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
<?php else: ?>

<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$uL = preg_replace_callback("|(\d+)|", "inc", $uL);
$uI = preg_replace_callback("|(\d+)|", "inc", $uI);
?>

<div class="form-group row">
<?php
if (strpos($key, 'password') === false && strpos($key, 'id') === false){ ?>
<label for="<?php echo e($uI); ?>" class="col-md-4 col-form-label text-md-right"> <?php echo e(ucfirst($key)); ?> </label>

<div class="col-md-6">

<input id="<?php echo e($uI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($uI); ?>" required autocomplete="username" readonly autofocus value="<?php echo e($value); ?>">
<?php }
else {  ?>

<div class="col-md-6">

<input type="hidden" id="<?php echo e($uI); ?>" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($uI); ?>" required autocomplete="username" value="<?php echo e($value); ?>">
<?php }
?>
<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
<span class="invalid-feedback" role="alert">
<strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- ----------- end card ----------- --> 
        </div>
        </div>
        
<!--     - - - - - - - - - - PORTFOLIO -- - -  - - - - -             -->
<div class="card" style="margin-top:10px">

<div class="card-header"><?php echo e(__('Portfolio')); ?></div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
<?php if($portfolio == null): ?> 
<?php
$pI = preg_replace_callback("|(\d+)|", "inc", $pI);
$pL = preg_replace_callback("|(\d+)|", "inc", $pL);
?>
<div class="form-group row">

<label for="<?php echo e($pL); ?>" class="col-md-4 col-form-label text-md-right">Portfolio</label>

<div class="col-md-6">
<input id="<?php echo e($pI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($pL); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus readonly placeholder="No job experience filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
<?php else: ?>
<?php if(is_countable($portfolio)): ?>
<?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $x++; ?>
<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keh => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$pI = preg_replace_callback("|(\d+)|", "inc", $pI);
$pL = preg_replace_callback("|(\d+)|", "inc", $pL);
$chain = "$keh";
if (strpos($keh, 'jobHistory') !== false){
$chain = "Job Experience " . $x;
} 
if (strpos($keh, 'jobSkills') !== false){
$chain = "Skills";
} 
if (strpos($keh, 'education') !== false){
$chain = "Education";
}
if ($val == null || $val == ""){
$value = "No data filed...";
} 
?>

<div class="form-group row">

<label for="<?php echo e($pL); ?>" class="col-md-4 col-form-label text-md-right"><?php echo e($chain); ?></label>

<div class="col-md-6">
<input id="<?php echo e($pI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($pL); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" readonly autofocus value=<?php echo e($val); ?> placeholder="<?php echo e($val); ?>">

<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
<span class="invalid-feedback" role="alert">
<strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endif; ?>
<!-- ----------- end card ----------- --> 
        </div>
        </div>
      
		
<!--  -->



<!--      ------------------ GROUPS ----------------------------- -->

<div class="card" style="margin-top:10px">
<div class="card-header"><?php echo e(__('Groups')); ?></div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
<?php if($groups == null): ?> 
<?php
$gI = preg_replace_callback("|(\d+)|", "inc", $gI);
$gL = preg_replace_callback("|(\d+)|", "inc", $gL);
?>
<div class="form-group row">

<label for="<?php echo e($gL); ?>" class="col-md-4 col-form-label text-md-right">Groups</label>

<div class="col-md-6">
<input id="<?php echo e($gI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($gI); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus readonly placeholder="No groups filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
<?php else: ?>

<?php for($x = 0; $x < count($groups); $x++): ?>
<?php
$gI = preg_replace_callback("|(\d+)|", "inc", $gI);
$gL = preg_replace_callback("|(\d+)|", "inc", $gL);
$gIdentity = preg_replace_callback("|(\d+)|", "inc", $gIdentity);
?>

<div class="form-group row">

<label for="<?php echo e($gL); ?>" class="col-md-4 col-form-label text-md-right"><?php echo e($gL); ?></label>

<div class="col-md-6">
<input id="<?php echo e($gI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($gI); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus readonly placeholder="<?php echo e($groups[$x]->getGroupName()); ?>">

<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
<span class="invalid-feedback" role="alert">
<strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
</div>

<?php endfor; ?>
<?php endif; ?>
<!-- ----------- end card ----------- --> 
        </div>
        </div>
        

<!--  -->
<!--     - - - - - - - - - - DEMOGRAPHICS  -- - -  - - - - -             -->
<div class="card" style="margin-top:10px">

<div class="card-header"><?php echo e(__('Demographics')); ?></div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
<?php if($demos == null): ?> 
<?php
$dI = preg_replace_callback("|(\d+)|", "inc", $dI);
$dL = preg_replace_callback("|(\d+)|", "inc", $dL);
?>
<div class="form-group row">

<label for="<?php echo e($dL); ?>" class="col-md-4 col-form-label text-md-right">Demographics</label>

<div class="col-md-6">
<input id="<?php echo e($dI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($dI); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus readonly placeholder="No data filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
<?php else: ?>
<?php $__currentLoopData = $demos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$chain = "$key";
$dI = preg_replace_callback("|(\d+)|", "inc", $dI);
$dL = preg_replace_callback("|(\d+)|", "inc", $dL);
if (strpos($key, 'age') !== false){
$chain = "Age";
} 
if (strpos($key, 'gender') !== false){
$chain = "Gender";
} 
if (strpos($key, 'address') !== false){
$chain = "Address";
}
if (strpos($key, 'phonenumber') !== false){
$chain = "Phone  Number";
}
?>

<div class="form-group row">

<label for="<?php echo e($dL); ?>" class="col-md-4 col-form-label text-md-right"><?php echo e($chain); ?></label>

<div class="col-md-6">
<input id="<?php echo e($dI); ?>" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($dI); ?>"  required autocomplete="username" autofocus readonly value="<?php echo e($value); ?>">

<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
<span class="invalid-feedback" role="alert">
<strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- ----------- end card ----------- --> 
        </div>
        </div>
      
		
<!--  -->
          <div class="form-group row mb-0">
        <div class="col-md-6 offset-md-4">
        <?php echo csrf_field(); ?>
      <!--    <button type="submit" name="action" value = 'post' style="margin-top:10px" class="btn btn-primary"> -->
<!--         <?php echo e(__('Send Friend Request')); ?> -->
<!--         </button> -->
        </div>
        </div>
        </div>
        </div>
        </div>
        
        
        
        
        
        
    </form>
      </div><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views//userPages/viewuser.blade.php ENDPATH**/ ?>