<?php $__env->startSection('content'); ?>

<html>
	<table style="width: 1300px; height:100px" cellpadding="15" border="1" align="center" id="admin">
		<thead>
			<tr align="center">
				<th>Profile</th>
				<th>Name </th>
				<th>Username </th>
				<th>Email</th>
				<th>Role</th>
			</tr>
		</thead>
		<tbody align="center"> 
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<tr>
            			<td>
            			<form action="theirProfile" method="post">
                            	<?php echo e(csrf_field()); ?>

                            	<input type="hidden" name='id' value='<?php echo e($user->id); ?>'>
                    			<input type="submit" value='View'>
                			</form>
                			</td>
                    	<td><?php echo e($user->name); ?></td>
                    	<td><?php echo e($user->username); ?></td>
                    	<td><?php echo e($user->email); ?></td>
                    	<td><?php echo e($user->role); ?></td>
                    	
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\adkCLC\resources\views//userPages/searchUserResults.blade.php ENDPATH**/ ?>