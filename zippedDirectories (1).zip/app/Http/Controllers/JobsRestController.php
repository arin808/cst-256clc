<?php

namespace App\Http\Controllers;

use App\Models\DTO;
use App\Services\Business\UserBS;
use App\Services\Business\GroupBS;
use App\Services\Business\JobListBS;
use App\Services\Data\Utility\ILoggerService;
use Carbon\Exceptions\Exception;
class JobsRestController extends Controller
{
	public function __construct(ILoggerService $logger)
	{
		$logger->info("Entering the job rest controller");
		try
		{
			$this->middleware('auth')->except('logout');
		}
		catch (Exception $e)
		{
			$logger->error("Error:", $e);
		}
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$security = new JobListBS();
		$ports = $security->getAllJobs();
		if ($ports == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $ports);
		$dto = json_encode($translate);
		return $dto;
	}
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		$security = new JobListBS();
		$port = $security->getJob($id);
		if ($port == null){
			$code = 400;
			$error = "Failure";
		}
		else {
			$code = 200;
			$error = "Success";
		}
		$translate = new DTO($code, $error, $port);
		$dto = json_encode($translate);
		return $dto;
		
		
	}
	
}
