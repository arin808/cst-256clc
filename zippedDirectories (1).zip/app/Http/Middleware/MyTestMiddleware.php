<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class MyTestMiddleware
{
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next)
	{
		Log::info("Entering Middleware");
		if ($request->email != null){
			Log::info("Not null, value :: " . $request->email);
			$value = Cache::store("file")->get("mydata");
			if ($value == null) {
				Log::info("1st cache value :: " . $request->email);
				Cache::store("file")->put("mydata", $request->email, 1);
			}
		}
		else {
			$value = Cache::store("file")->get("mydata");
			if ($value != null){
				Log::info("Retrieving email from cache ::" . $value);
			}
			else {
				Log::info("Cache failure (data is older than 1 minute)");
			}
		}
		return $next($request);
	}
}
