<?php
namespace App\Services\Business;

use App\Models\MoreInfoModel;
use App\Models\UserModel;
use App\Services\Data\UserDAO;
use App\Services\Data\AcidDAO;

class UserBS
{

    // Define properties
    private $service;

    public function getAll()
    {
        // Instantiate UserDAO class
        $this->service = new UserDAO();

        // Return array
        return $this->service->getAllUsers();
    }

    public function getUser($id)
    {
        $this->service = new UserDAO();

        return $this->service->getUser($id);
    }
    public function getUserName($id)
    {
        $this->service = new UserDAO();
        
        return $this->service->getUserName($id);
    }
    public function editUser(UserModel $user)
    {
        $this->service = new UserDAO();

        return $this->service->editUser($user);
    }
    public function searchUsers($searchTerm)
    {
        $this->service = new UserDAO();
        
        return $this->service->searchUsers($searchTerm);
    }
    
    public function editall(UserModel $credentials, MoreInfoModel $info, $usernamee)
    {
    	$servername = "localhost";
    	$username = "root";
    	$password = "root";
    	$dbname = "cst-256";
    	$port = 8889;
    	$conn = mysqli_connect($servername, $username, $password, $dbname, $port);
    	//start ACID
    	$conn->autocommit(FALSE);
    	$conn->begin_transaction();
    	$dao = new AcidDAO($conn);
    	$useredited = $dao->updateUser($credentials);
    	$infoedited = $dao->updateInfo($info);
    	if ($this->getUserName($credentials->id) == null){
    	    $nedited = $dao->insertname($usernamee, $credentials->id);
    	}
    	else {
    	    $nedited = $dao->updatename($usernamee, $credentials->id);
    	}
    	if ($useredited && $infoedited && $nedited){
    		$conn->commit();
    	}
    	else {
    		$conn->rollback();
    	}
    	mysqli_close($conn);
    	
    }
    public function getInfo($id){
    	$this->service = new UserDAO();
    	
    	return $this->service->getInfo($id);
    }
    public function suspend($id)
    {
        $this->service = new UserDAO();

        return $this->service->suspend($id);
    }

    public function delete($id)
    {
        $this->service = new UserDAO();

        return $this->service->delete($id);
    }

    public function addNewInfo($moreInfoData, $id)
    {
        $this->service = new UserDAO();

        return $this->service->addNewInfo($moreInfoData, $id);
    }
    public function getUserPortfolio($id)
    {
        $this->service = new UserDAO();
        
        return $this->service->getUserPortfolio($id);
    }
    
    public function addUserPortfolio($userPortfolioData, $id) 
    {
        $this->service = new UserDAO();
                
        return $this->service->addUserPortfolio($userPortfolioData, $id);
    }
    
    public function getGroups($id){
    	$this->service = new UserDAO();
    	
    	return $this->service->getGroups($id);
    }
}

