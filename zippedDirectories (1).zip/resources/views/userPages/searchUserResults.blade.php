@extends('layouts.app')
@section('content')

<html>
	<table style="width: 1300px; height:100px" cellpadding="15" border="1" align="center" id="admin">
		<thead>
			<tr align="center">
				<th>Profile</th>
				<th>Name </th>
				<th>Username </th>
				<th>Email</th>
				<th>Role</th>
			</tr>
		</thead>
		<tbody align="center"> 
                @foreach($users as $user)
            		<tr>
            			<td>
            			<form action="theirProfile" method="post">
                            	{{csrf_field()}}
                            	<input type="hidden" name='id' value='{{$user->id}}'>
                    			<input type="submit" value='View'>
                			</form>
                			</td>
                    	<td>{{$user->name}}</td>
                    	<td>{{$user->username}}</td>
                    	<td>{{$user->email}}</td>
                    	<td>{{$user->role}}</td>
                    	
                    </tr>
            @endforeach
		</tbody>
	</table>
</html>
@endsection
