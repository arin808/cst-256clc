<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta name="csrf-token" content="{{ csrf_token() }}">
</html>
@php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_ERROR);
function inc($matches) {
    return ++$matches[1];
}
$i = 0;
$uI = "user0";
$uL = "Property 0";
$pI = "exp0";
$pL = "Experience 0";
$gI = "group0";
$gL = "Group 0";
$dI = "demo0";
$dL = "Demographics 0";
$chain = "null";
$gIdentity = "gId0";
$x = 0;
@endphp
<!-- loop through history, assign new form group col -->
<!-- increment history, assign placeholder as history[x]->getHistory -->
@include('layouts.app')
<h1> Admin Interface </h1>
<style>
.flex {
display: flex;
   flex-direction: row;
}
.responsive {
  max-width: 100%;
  height: auto;
}
</style>
<div class= "responsive">
@csrf
<form method="POST" action='doEdit'>



<div class="container">
<div class="row justify-content-center">
<div class="col-md-8">
<!--      ------------------ USER ----------------------------- -->

<div class="card" style="margin-top:10px">
<div class="card-header">{{ __('User') }}</div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
@if ($user == null) 
<div class="form-group row">

<label for="userid" class="col-md-4 col-form-label text-md-right">ID</label>

<div class="col-md-6">
<input id="userid" type="text" class="form-control @error('username') is-invalid @enderror" name="userid" value="{{ old('username') }}" required autocomplete="username" autofocus readonly placeholder="No Data Filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
@else
@php if ($username == null) $username = "Enter Username..."; @endphp
<div class="form-group row">
<label for="username" class="col-md-4 col-form-label text-md-right"> Username </label>
<div class="col-md-6">
<input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" required autocomplete="username" autofocus value="{{$username}}">
@error('username')
<span class="invalid-feedback" role="alert">
<strong>{{ $message }}</strong>
</span>
@enderror
</div>
</div>
@foreach ($user as $key => $value)
@php
$uL = preg_replace_callback("|(\d+)|", "inc", $uL);
$uI = preg_replace_callback("|(\d+)|", "inc", $uI);
@endphp

<div class="form-group row">

<label for="{{$uI}}" class="col-md-4 col-form-label text-md-right"> {{ ucfirst($key) }} </label>

<div class="col-md-6">
@php
if (strpos($key, 'password') === false && strpos($key, 'id') === false && strpos($key, 'role') === false){ @endphp
<input id="{{$uI}}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{$uI}}" required autocomplete="username" autofocus value="{{$value}}">
@php }
else {  @endphp
<input id="{{$uI}}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{$uI}}" required autocomplete="username" readonly autofocus value="{{$value}}">
@php }
@endphp
@error('username')
<span class="invalid-feedback" role="alert">
<strong>{{ $message }}</strong>
</span>
@enderror
</div>

</div>

@endforeach
@endif
<!-- ----------- end card ----------- --> 
        </div>
        </div>
        
<!--     - - - - - - - - - - PORTFOLIO -- - -  - - - - -             -->
<div class="card" style="margin-top:10px">

<div class="card-header">{{ __('Portfolio') }}</div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
@if ($portfolio == null) 
@php
$pI = preg_replace_callback("|(\d+)|", "inc", $pI);
$pL = preg_replace_callback("|(\d+)|", "inc", $pL);
@endphp
<div class="form-group row">

<label for="{{ $pL }}" class="col-md-4 col-form-label text-md-right">Portfolio</label>

<div class="col-md-6">
<input id="{{ $pI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $pL }}" value="{{ old('username') }}" required autocomplete="username" autofocus readonly placeholder="No job experience filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
@else
@if(is_countable($portfolio))
@foreach($portfolio as $key => $value)
@php $x++; @endphp
@foreach ($value as $keh => $val)

@php
$pI = preg_replace_callback("|(\d+)|", "inc", $pI);
$pL = preg_replace_callback("|(\d+)|", "inc", $pL);
$chain = "$keh";
if (strpos($keh, 'jobHistory') !== false){
$chain = "Job Experience " . $x;
} 
if (strpos($keh, 'jobSkills') !== false){
$chain = "Skills";
} 
if (strpos($keh, 'education') !== false){
$chain = "Education";
}
if ($val == null || $val == ""){
$value = "No data filed...";
} 
@endphp

<div class="form-group row">

<label for="{{ $pL }}" class="col-md-4 col-form-label text-md-right">{{$chain}}</label>

<div class="col-md-6">
<input id="{{ $pI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $pL }}" value="{{ old('username') }}" required autocomplete="username" readonly autofocus value={{$val}} placeholder="{{$val}}">

@error('username')
<span class="invalid-feedback" role="alert">
<strong>{{ $message }}</strong>
</span>
@enderror
</div>

</div>
@endforeach
@endforeach
@endif
@endif
<!-- ----------- end card ----------- --> 
        </div>
        </div>
      
		
<!--  -->



<!--      ------------------ GROUPS ----------------------------- -->

<div class="card" style="margin-top:10px">
<div class="card-header">{{ __('Groups') }}</div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
@if ($groups == null) 
@php
$gI = preg_replace_callback("|(\d+)|", "inc", $gI);
$gL = preg_replace_callback("|(\d+)|", "inc", $gL);
@endphp
<div class="form-group row">

<label for="{{ $gL }}" class="col-md-4 col-form-label text-md-right">Groups</label>

<div class="col-md-6">
<input id="{{ $gI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $gI }}" value="{{ old('username') }}" required autocomplete="username" autofocus readonly placeholder="No groups filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
@else

@for ($x = 0; $x < count($groups); $x++)
@php
$gI = preg_replace_callback("|(\d+)|", "inc", $gI);
$gL = preg_replace_callback("|(\d+)|", "inc", $gL);
$gIdentity = preg_replace_callback("|(\d+)|", "inc", $gIdentity);
@endphp

<div class="form-group row">

<label for="{{ $gL }}" class="col-md-4 col-form-label text-md-right">{{ $gL }}</label>

<div class="col-md-6">
<input id="{{ $gI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $gI }}" value="{{ old('username') }}" required autocomplete="username" autofocus readonly placeholder="{{ $groups[$x]->getGroupName() }}">

@error('username')
<span class="invalid-feedback" role="alert">
<strong>{{ $message }}</strong>
</span>
@enderror
</div>
<div>
       <input type = 'hidden' name = '_token' value = '" . csrf_token() . "'>
       <button type='submit' id = 'delete' name='action' value="{{$groups[$x]->getGroupID()}}" class="btn btn-primary">-</button>
       <input type='hidden' name="gid" id="gid" value="{{$groups[$x]->getGroupID()}}"></input>
</div>
</div>

@endfor
@endif
<!-- ----------- end card ----------- --> 
        </div>
        </div>
        

<!--  -->
<!--     - - - - - - - - - - DEMOGRAPHICS  -- - -  - - - - -             -->
<div class="card" style="margin-top:10px">

<div class="card-header">{{ __('Demographics') }}</div>

<div class="card-body">

<!-- ----------- repeat this card ----------- -->
@if ($demos == null) 
@php
$dI = preg_replace_callback("|(\d+)|", "inc", $dI);
$dL = preg_replace_callback("|(\d+)|", "inc", $dL);
@endphp
<div class="form-group row">

<label for="{{ $dL }}" class="col-md-4 col-form-label text-md-right">Demographics</label>

<div class="col-md-6">
<input id="{{ $dI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $dI }}" value="{{ old('username') }}" required autocomplete="username" autofocus readonly placeholder="No data filed...">

</div>
</div>
<!-- ----------- load data ----------- -->
@else
@foreach($demos as $key => $value)
@php
$chain = "$key";
$dI = preg_replace_callback("|(\d+)|", "inc", $dI);
$dL = preg_replace_callback("|(\d+)|", "inc", $dL);
if (strpos($key, 'age') !== false){
$chain = "Age";
} 
if (strpos($key, 'gender') !== false){
$chain = "Gender";
} 
if (strpos($key, 'address') !== false){
$chain = "Address";
}
if (strpos($key, 'phonenumber') !== false){
$chain = "Phone  Number";
}
@endphp

<div class="form-group row">

<label for="{{ $dL }}" class="col-md-4 col-form-label text-md-right">{{$chain}}</label>

<div class="col-md-6">
<input id="{{ $dI }}" type="text" class="form-control @error('username') is-invalid @enderror" name="{{ $dI }}"  required autocomplete="username" autofocus value="{{$value}}">

@error('username')
<span class="invalid-feedback" role="alert">
<strong>{{ $message }}</strong>
</span>
@enderror
</div>

</div>
@endforeach
@endif
<!-- ----------- end card ----------- --> 
        </div>
        </div>
      
		
<!--  -->
          <div class="form-group row mb-0">
        <div class="col-md-6 offset-md-4">
        @csrf
        <button type="submit" name="action" value = 'post' style="margin-top:10px" class="btn btn-primary">
        {{ __('Update Profile') }}
        </button>
        </div>
        </div>
        </div>
        </div>
        </div>
        
        
        
        
        
        
    </form>
      </div>