<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Business\BusinessService;
use App\Models\UserModel;
use App\Models\MoreinfoModel;
use App\Http\Middleware\Suspended;

class AdminController extends Controller
{
    public function index()
    {
        // Instantiate Business layer to access data
        $bs = new BusinessService();
        
        //Obtain data
        $users = $bs->getAll();

        return view('admin')->with('users', $users);
    }
    
    public function editView(Request $request)
    {
        $id = request()->get('id');
        $bs = new BusinessService();
        
        $user = $bs->getUser($id);
        
        return View('editUser')->with('user', $user);
    }
    
    public function editUser(Request $request)
    {
        $id = request()->get('id');
        $name = request()->get('name');
        $email = request()->get('email');
        $password = request()->get('password');
        $role = request()->get('role');
        $user = new UserModel($id, $name, $email, $password, $role);
        
        $bs = new BusinessService();
        
        $bs->editUser($user);
  
        $all = $bs->getAll();
        return View('admin')->with('users', $all);
    }
    
    public function suspend(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new BusinessService();
        
        
        if($bs->suspend($id))
        {
            echo "success";
        }
        else 
        {
            echo "fail";
        }
        $users = $bs->getAll();
        
        return View('admin')->with('users', $users);
        
    }
    
    public function delete(Request $request)
    {
        $id = request()->get('id');
        
        $bs = new BusinessService();
        
        $bs->delete($id);
        
        $users = $bs->getAll();
        
        return View('admin')->with('users', $users);
    }
    
    public function addNewInfo(Request $request)
    {
        $moreInfoData = new MoreInfoModel(request()->get('age'), request()->get('gender'),request()->get('phonenumber'),request()->get('address'));
        
        $bs = new BusinessService();
        
        $isValid = $bs->addNewInfo($moreInfoData);
        
        if($isValid)
        {
            echo("customer data added!");
            return view('home');
        }
        else
        {
            echo("customer data not added. you got it next time!");
            return view('moreinfo');
        }
        
    }
}
