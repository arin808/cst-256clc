<?php
namespace App\Services\Business;
use App\Models\UserModel;
use App\Services\Data\DAO;
class BusinessService
{
    // Define properties
    private $service;

    public function getAll()
    {
        // Instantiate DAO class
        $this->service = new DAO();
        
        // Return array
        return $this->service->getAllUsers();
    }
    
    public function getUser($id)
    {
        $this->service = new DAO();
        
        return $this->service->getUser($id);
    }
    
    public function editUser(UserModel $user)
    {
        $this->service = new DAO();
        
        return $this->service->editUser($user);
    }
    
    public function suspend($id)
    {
        $this->service = new DAO();
        
        return $this->service->suspend($id);
    }
    
    public function delete($id)
    {
        $this->service = new DAO();
        
        return $this->service->delete($id);
    }
    public function addNewInfo($moreInfoData) {
        
        $this->service = new DAO();
        
        return $this->service->addNewInfo($moreInfoData);
        
    }
}

