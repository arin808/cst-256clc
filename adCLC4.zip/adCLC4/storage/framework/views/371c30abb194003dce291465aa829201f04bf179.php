<html >
	<h5 align="center">Arin Aihara and Austin Driver CLC Milestone Project</h5>
</html><?php /**PATH /Users/AustinDriver/Documents/CST-256/adCLC4/resources/views/layouts/footer.blade.php ENDPATH**/ ?>